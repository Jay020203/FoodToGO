# food-delivery-app-ui

## Live Link: https://muqsitadam.github.io/food-delivery-app-ui/

## ABOUT
This is a team project from three interns at the laptop for developers program cohort 3. It is the landing page of a food delivery app UI. Built with HTML, CSS and JS, It is also responsive as well. This project was used to test our skills using HTML and CSS
